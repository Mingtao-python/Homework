from flask import Flask, render_template, request

from prompt_filter import filter_prompt
from src.Implementation1.similarity import cosine_similarity
from src.Implementation2.tfidf_search import search
from src.Implementation3.embedding_similarity import cosine
from src.Implementation4.vector_search import top_k, euclidean_search
from src.Implementation5.embedding_search import search2
from src.Implementation6.gradient_descent_demo import run_gradient_demo
from src.Implementation7.embedding_failure_analysis import find_failure_cases
from src.shared import euclidean_distance

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False


@app.route("/", methods=["GET", "POST"])
def index():
    selected_algorithm = request.form.get("algorithm", "cosine") if request.method == "POST" else "cosine"
    q = request.form.get("query", "").strip() if request.method == "POST" else ""

    if request.method == "POST":
        ok, message = filter_prompt(q)
        if not ok:
            return render_template("index.html", error=message, selected_algorithm=selected_algorithm)

        cosine_result = cosine_similarity(q, "semantic search over documents")
        euclidean_result = euclidean_distance(q, "semantic search over documents")
        tfidf_results = search(q)
        embedding_matrix = cosine()
        vector_results = top_k(q)
        euclidean_results = euclidean_search(q)
        embedding_results = search2(q)
        gradient_summary = run_gradient_demo(learning_rate=0.01, epochs=200)
        failure_cases = find_failure_cases(q)
        return render_template(
            "index.html",
            cosine_result=cosine_result,
            euclidean_result=euclidean_result,
            tfidf_results=tfidf_results,
            embedding_matrix=embedding_matrix,
            vector_results=vector_results,
            euclidean_results=euclidean_results,
            embedding_results=embedding_results,
            gradient_summary=gradient_summary,
            failure_cases=failure_cases,
            error=None,
            selected_algorithm=selected_algorithm,
        )

    return render_template(
        "index.html",
        error=None,
        cosine_result=None,
        euclidean_result=None,
        tfidf_results=[],
        embedding_matrix=[],
        vector_results=[],
        euclidean_results=[],
        embedding_results=[],
        gradient_summary={"learning_rate": 0.01, "epochs": 200, "losses": [], "final_parameters": {"w": 0.0, "b": 0.0}},
        failure_cases=[],
        selected_algorithm="cosine",
    )


if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0", port=5000)