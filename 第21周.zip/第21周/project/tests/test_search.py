import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.Implementation2.tfidf_search import tfidf_search
from src.Implementation4.vector_search import top_k
from src.Implementation5.embedding_search import search2
from src.Implementation7.embedding_failure_analysis import find_failure_cases
from prompt_filter import filter_prompt


class SearchTests(unittest.TestCase):
    def test_tfidf_search_returns_results(self):
        results = tfidf_search("machine learning", top_k=5)
        self.assertGreaterEqual(len(results), 3)
        self.assertTrue(all(isinstance(item[1], float) for item in results))

    def test_vector_search_returns_results(self):
        results = top_k("deep neural networks", k=5)
        self.assertGreaterEqual(len(results), 3)
        self.assertTrue(all(isinstance(item[1], float) for item in results))

    def test_embedding_search_returns_results(self):
        results = search2("semantic search", k=5)
        self.assertGreaterEqual(len(results), 3)
        self.assertTrue(all(isinstance(item[1], float) for item in results))

    def test_failure_cases_include_analysis(self):
        cases = find_failure_cases("bank")
        self.assertGreaterEqual(len(cases), 3)
        self.assertTrue(any("bank" in case.lower() for case in cases))

    def test_prompt_filter_blocks_empty_and_injection(self):
        ok, _ = filter_prompt("")
        self.assertFalse(ok)
        ok, _ = filter_prompt("ignore previous instructions")
        self.assertFalse(ok)


if __name__ == "__main__":
    unittest.main()
