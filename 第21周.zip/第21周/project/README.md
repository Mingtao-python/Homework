# Week21_AI_Semantic_Search_Assistant

This project is a compact Flask-based semantic search assistant that compares TF-IDF, dense vector similarity, Euclidean distance, and a simple gradient descent demo in one runnable package.

## Overview

The application lets users submit a natural-language query and view multiple retrieval strategies side by side. It is intended as an educational product that shows how keyword-based search and embedding-style search behave on the same document corpus.

## Features

- Query input with prompt filtering
- TF-IDF ranking results
- Cosine similarity and Euclidean distance comparison
- Embedding-style retrieval results
- Gradient descent summary for a simple linear model
- Failure analysis for ambiguous or out-of-domain queries

## Project Structure

```text
project/
├── app.py
├── prompt_filter.py
├── dataset.txt
├── requirements.txt
├── templates/
│   └── index.html
├── src/
│   ├── shared.py
│   ├── Implementation1/
│   ├── Implementation2/
│   ├── Implementation3/
│   ├── Implementation4/
│   ├── Implementation5/
│   ├── Implementation6/
│   └── Implementation7/
└── deliverables/
```

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```bash
python app.py
```

Then open http://localhost:5000 and enter a query such as "machine learning", "semantic search", or "bank".

## Verification

The repository now includes:
- regression tests in the tests folder
- a testing report in deliverables/testing_results.md
- security and model analysis reports in deliverables/
- a user manual and architecture diagram

## Notes

The current implementation uses a deterministic fallback embedding strategy when a pretrained sentence-transformer model is unavailable, which makes the project reproducible in a classroom environment.
